/*jQuery(document).ready(function(){

			jQuery('input.text_field').each(function(e){
			         jQuery(this).on
				
				});
	});
	*/
	
jQuery(document).ready(function(){
	jQuery("input.text_field").bind({
		focus: function() { (jQuery(this).val() == jQuery(this).attr('id'))?jQuery(this).val(""):'';},
		blur: function() { (jQuery(this).val() == '')?jQuery(this).val(jQuery(this).attr('id')):'';}
	});
})	
	
	jQuery(document).ready(function(){
	jQuery("input.text_field_rel").bind({
		focus: function() { (jQuery(this).val() == jQuery(this).attr('title'))?jQuery(this).val(""):'';},
		blur: function() { (jQuery(this).val() == '')?jQuery(this).val(jQuery(this).attr('title')):'';}
	});
})	
	