<?php
//echo "<pre>";
//print_r($form);
//echo "</pre>";
?>

			<div class="infomation">
                	<h1>Affordable Coverage is Just 3 Steps Away</h1>
                    <div class="information-steps">
                    	<div class="steps">
                        	<ul>
                            	<a href="#">
                                	<li class="address-step1">
                                        <h1>Personal Information</h1>
                                    </li>
                                </a>
                                <a href="#">
                                    <li class="address-step2">
                                        <h1>Address Information</h1>
                                    </li>
                                </a>
                                <a href="#">
                                    <li class="address-step3">
                                        <h1>Payment</h1>
                                    </li>
                                </a>
                            </ul>
                        </div>
                        <div class="security-icon">
                        	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/security-logo.png" /></a>
                        </div>
                    </div>
                    <div class="information-details">
                    	<div class="info-left">
                        	<h1>Household Address</h1>
                            <div class="info-detail">
                            	<h4>Warning language red. Shows with red x if issue.</h4>
                                <div class="fields">
                                	<div class="field-name">
                                    	First Name<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['house_hold_first_name']); ?>
                                        </div>
                                        <div class="cross-icon">
                                        	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/cross-icon.png" /></a>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Last Name<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['house_hold_last_name']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Full Name On Credit Card<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['name_on_credit_card']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Street Address<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['street_address']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Street Address 2
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['street_address_two']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	City<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['household_city']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="state-field">
                                    	<div class="state-field-name">
                                        	State<span>*</span>
                                        </div>
                                        <div class="state-select">
                                        	<?php echo drupal_render($form['solutions']['household_state']); ?>
                                        </div>
                                    </div>
                                    <div class="zip-field">
                                    	<div class="zip-field-name">
                                        	Zip<span>*</span>
                                        </div>
                                        <div class="zip-input-field">
                                        	<?php echo drupal_render($form['solutions']['household_zip']); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="address-info-right">
                        	<h1>Billing Address</h1>
                            <div class="info-detail">
                            	<div class="fields">
                                	<div class="field-chkbox">
                                    	<?php echo drupal_render($form['solutions']['billing_same_as_household_address']); ?>
                                    </div>
                                    <div class="billing-address-txt">
                                    	<h5>Same as Household Address</h5>
                                    </div>
                                </div>
                                <div class="fields">
                                	<div class="field-chkbox">
                                    	<?php echo drupal_render($form['solutions']['billing_different_than_household_address']); ?>
                                    </div>
                                    <div class="billing-address-txt">
                                    	<h5>Different than Household Address</h5>
                                    </div>
                                </div>
                            	<h4>Warning language red. Shows with red x if issue.</h4> 
                                <div class="fields">
                                	<div class="field-name">
                                    	Street Address<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['billing_street_address']); ?>
                                        </div>
                                        <div class="cross-icon">
                                        	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/cross-icon.png" /></a>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Street Address 2
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['billing_street_address_two']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	City<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['billing_city']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="state-field">
                                    	<div class="state-field-name">
                                        	State<span>*</span>
                                        </div>
                                        <div class="state-select">
                                        	<?php echo drupal_render($form['solutions']['billing_state']); ?>
                                        </div>
                                    </div>
                                    <div class="zip-field">
                                    	<div class="zip-field-name">
                                        	Zip<span>*</span>
                                        </div>
                                        <div class="zip-input-field">
                                        	<?php echo drupal_render($form['solutions']['billing_zip']); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Primary Phone<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['billing_primary_phone_number']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="billing-next-btn">
                                	<a href="#">
                                    	<img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/next-btn.png" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php echo drupal_render_children($form); ?>
												
												
												