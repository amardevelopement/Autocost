<?php

/*echo "<pre>";*/

//echo drupal_render($form);

//echo "<pre>";

//print_r($form);

//echo "</pre>";

//echo 'i am here'.$form['#node']->nid;

?>

				<div class="infomation">
                	<h1>Affordable Coverage is Just 3 Steps Away</h1>
                    <div class="information-steps">
                    	<div class="steps">
                        	<ul>
                            	<a href="#">
                                	<li class="step1">
                                	<h1>Personal Information</h1>
                                </li>
                                </a>
                                <a href="#">
                                    <li class="step2">
                                        <h1>Address Information</h1>
                                    </li>
                                </a>
                                <a href="#">
                                    <li class="step3">
                                        <h1>Payment</h1>
                                    </li>
                                </a>
                            </ul>
                        </div>
                        <div class="security-icon">
                        	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/security-logo.png" /></a>
                        </div>
                    </div>
                    <div class="information-details">
                    	<div class="info-left">
                        	<h1>Personal Information</h1>
                            <div class="info-detail">
                            	<h4>Warning language red. Shows with red x if issue.</h4>
                                <div class="fields">
                                	<div class="field-name">
                                    	Your Home City<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['home_city']); ?>
                                        </div>
                                        <div class="cross-icon">
                                        	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/cross-icon.png" /></a>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="state-field">
                                    	<div class="state-field-name">
                                        	State<span>*</span>
                                        </div>
                                        <div class="state-select">
                                        	<?php echo drupal_render($form['solutions']['state']); ?>
                                        </div>
                                    </div>
                                    <div class="zip-field">
                                    	<div class="zip-field-name">
                                        	Zip<span>*</span>
                                        </div>
                                        <div class="zip-input-field">
                                        	<?php echo drupal_render($form['solutions']['zipcode']); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Primary Phone<span>*</span>
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                            <?php echo drupal_render($form['solutions']['primary_phone']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="fields">
                                	<div class="field-name">
                                    	Secondary Phone
                                    </div>
                                    <div class="city-field">
                                    	<div class="input-text-field">
                                           <?php echo drupal_render($form['solutions']['secondary_phone']); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="last-fields">
                                	<div class="options-field">
                                    	<div class="state-field-name">
                                        	How Many Cars Do You Have?<span>*</span>
                                        </div>
                                        <div class="option-select">
                                        	 <?php echo drupal_render($form['solutions']['how_many_cars']); ?>
                                        </div>
                                    </div> 
                                    <div class="next-btn">
                                    	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/next-btn.png" /></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="info-right">
                        	<div class="money-back">
                            	<div class="money-add">
                                	<div class="money-back-gurantee"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/guarantee-img.png" /></div>
                                </div>
                            </div>
                            <div class="money-back-txt">
                            	<h1>30-Day Money Back Guarantee</h1>
                                <p>If for any reason you're not happy with the benefits and protection offered - simply call our toll-free number within the first 30 days to cancel and you'll receive a full refund - no questions asked. </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
						
						
				    <?php echo drupal_render_children($form); ?>