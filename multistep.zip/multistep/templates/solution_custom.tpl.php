<script>
function slide(){
setTimeout(function(){
		$('#myclass').fadeOut(4000,function(){
		var t=$(this).next();
        t.fadeIn(2000,function(){
			setTimeout(function(){
			t.fadeOut(4000,function(){
				$('#myclass').fadeIn(2000,function(){
				slide();
				});
				});
								},5000);
			});

		});
	},5000);
	}
$(document).ready(function(){
	slide();
	});
</script>	
<!-- ===================================== BANNER AREA START ================================== -->
    	<div class="banner">
        	<div class="inner-wrapper">
            	<div class="slider" id="myclass">
                	<div class="slider-content">
                    	<span>"Every used car owner  should have this  protection." </span>
   						<h3>— 	Jonas K., Customer Since 2012</h3>
                        <div class="gurantee-img">
                        	<img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/guarantee-img.png" />
                        </div>
                    </div>
                </div>
                <div class="slider-img-2" style="display:none;">
                	<div class="slider2-slider-content">
                    	<div class="slider-txt">
                        	<div class="slider2-gurantee-img">
                                <img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/slider-2-gurntee.png" />
                            </div>
                            <div class="slider-2-txt">
                            	<h1>"Expensive surprises aren't so scary to us any more.    Driving an older car makes good sense again!"</h1>
                                <p> —  Jonas K., Customer Since 2012</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- ===================================== BANNER AREA END ================================== -->
    
    <!-- ===================================== BENEFITES AND FORM AREA START ==================== -->
    	<div class="benefits-form">
        	<div class="inner-wrapper">
            	<div class="benefits-form-inner">
                	<div class="benefits-form-left">
                    	<h1>Four Great Protection Benefits</h1>
                        <p>ONE LOW MONTHLY COST COVERS:</p>
                        <div class="benefits">
                        	<ul>
                            	<li class="list-no1">
                                	<p>Routine Maintenance</p>
                                </li>
                                <li class="list-no2">
                                	<p>Car Repair Reimbursement</p>
                                </li>
                                <li class="list-no3">
                                	<p>Insurance Deductible Reimbursement</p>
                                </li>
                                <li class="list-no4">
                                	<p>Emergency Roadside Assistance</p>
                                </li>
                            </ul>
                        </div>
                        <div class="price">
                        	<span>only</span>
                            <h1><span> $</span>14</h1>
                            <h3>95/mo</h3>
                            <p>Includes All the Cars You Own!</p>
                        </div>
                    </div>
                    <div class="benefits-form-right">
                    	<div class="benefit-form">
                        	<div class="get-coverage">
                            	<h1>Get COVERAGE TODAY!</h1>
                            </div>
                            <div class="form">
                            	<div class="text-field">
                                	<div class="field-name">
                                    	First Name<span>*</span>
										<?php echo drupal_render($form['solutions']['first_name']); ?>
                                    </div>
                                </div>
                                <div class="text-field">
                                	<div class="field-name">
										Last Name<span>*</span>
                                    	<?php echo drupal_render($form['solutions']['last_name']); ?>
                                    </div>
                                </div>
                                <div class="text-field">
                                	<div class="field-name">
										Email Address<span>*</span>
                                    	<?php echo drupal_render($form['solutions']['email_address']); ?>
                                    </div>
                                </div>
                                <div class="text-field">
                                	<div class="field-name">
										Confirm Email Address<span>*</span>
                                    	<?php echo drupal_render($form['solutions']['confirm_email_address']); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="accept">
                            	<div class="accept-chkbox">
                                	<?php echo drupal_render($form['solutions']['newsletter_subscribe']); ?>
                                </div>
                            </div>
                            <div class="get-started-btn">
                            	<?php echo drupal_render_children($form); ?>
								<p>The email address you have entered will be your user identification, and will be necessary each time you enter the LOGIN portion of this website.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="security-logo">
                	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/security-logo.png" /></a>
                </div>
        </div>
    
    <!-- ===================================== BENEFITES AND FORM AREA END ==================== -->
    
    <!-- ===================================== CONTAINER PART START =========================== -->
    		<div class="container">
            	<div class="inner">
                	<div class="cont-inner">
                        <div class="cont-box">
                            <h1>Cancel Any Time.</h1>
                            <p>With Auto Cost Coverage, there are no annual contracts or hidden costs.  If you ever decide to cancel – you are free to do so at any time for any reason.</p>
                        </div>
                        <div class="cont-box">
                            <h1>No Down Payment.</h1>
                            <p>Unlike many warranties, Auto Cost Coverage has no upfront fees or deposits. Just $14.95 a month starts your coverage today!</p>
                        </div>
                        <div class="last-cont-box">
                            <h1>Any Make, Mileage, or Year.</h1>
                            <p>It doesn't matter if your car has 400,000 miles on it, or if its 30 years old.  If you're driving it – we'll cover it.</p>
                        </div>
                    </div>
                    <div class="cont-btm">
                    	<h1>Our Trusted Maintenance Network has over 38,000 Providers Nationwide, including:</h1>
                        <div class="clients">
                        	<ul>
                            	<li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/client1.png" /></a></li>
                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/client2.png" /></a></li>
                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/client3.png" /></a></li>
                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/client4.png" /></a></li>
                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/client5.png" /></a></li>
                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/client6.png" /></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
    <!-- ===================================== CONTAINER PART END =========================== -->
