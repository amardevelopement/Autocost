<?php

/*echo "<pre>";*/

//echo drupal_render($form);

/*echo "<pre>";

print_r($form);

echo "</pre>";*/

//echo 'i am here'.$form['#node']->nid;

?>
				  
				  <div class="infomation">
                	<h1>Affordable Coverage is Just 3 Steps Away</h1>
                    <div class="information-steps">
                    	<div class="steps">
                        	<ul>
                            	<a href="#">
                                	<li class="payment-step1">
                                        <h1>Personal Information</h1>
                                    </li>
                                </a>
                                <a href="#">
                                    <li class="payment-step2">
                                        <h1>Address Information</h1>
                                    </li>
                                </a>
                                <a href="#">
                                    <li class="payment-step3">
                                        <h1>Payment</h1>
                                    </li>
                                </a>
                            </ul>
                        </div>
                        <div class="security-icon">
                        	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/security-logo.png" /></a>
                        </div>
                    </div>
                    <div class="information-details">
                    	<div class="payment-info">
                        	<h1>Payment Information</h1>
                            <div class="payment-info-inner">
                            	<h4>Offer Details:</h4>
                                <p>To process my Auto Cost Coverage account, a valid credit card is required. I understand that I will be billed $14.95 for each month that I remain a member. If I cancel within the first 30 days, I will receive a refund of my first month's fees.</p>
                                <div class="payment-details">
                                	<div class="payment-detail-left">
                                    	<h4>Warning language red. Shows with red x if issue.</h4>
                                        <div class="payment-option">
                                        	<ul>
                                            	<li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/payment-icon1.png" /></a></li>
                                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/payment-icon2.png" /></a></li>
                                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/payment-icon3.png" /></a></li>
                                                <li><a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/payment-icon4.png" /></a></li>
                                            </ul>
                                        </div>
                                        <div class="payment-info-fields">
                                        	<div class="fields">
                                                <div class="field-name">
                                                    Card Number<span>*</span>
                                                </div>
                                                <div class="city-field">
                                                    <div class="payment-input-text-field">
                                                        <?php echo drupal_render($form['solutions']['card_number']); ?>
                                                    </div>
                                                    <div class="cross-icon">
                                                        <a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/cross-icon.png" /></a>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="fields">
                                                <div class="state-field">
                                                    <div class="state-field-name">
                                                        Expiration Month<span>*</span>
                                                    </div>
                                                    <div class="state-select">
                                                        <?php echo drupal_render($form['solutions']['card_expiry_month']); ?>
                                                    </div>
                                                </div>
                                                <div class="zip-field">
                                                    <div class="zip-field-name">
                                                       Expiration Year<span>*</span>
                                                    </div>
                                                    <div class="expiration-input-field">
                                                       <?php echo drupal_render($form['solutions']['card_expiry_year']); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="fields">
                                                <div class="security-field">
                                                    <div class="zip-field-name">
                                                        Card Security Code (CSC)<span>*</span>
                                                    </div>
                                                    <div class="security-input-field">
                                                        <?php echo drupal_render($form['solutions']['card_security_code']); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="payment-btm-txt">
                                        	<p>Credit/debit card processing is performed by Coverdell.</p>
                                        </div>
                                    </div>
                                    <div class="payment-detail-right">
                                    	<p>By clicking below, I apply for membership in the Auto CostCoverage Plan, and the $14.95 monthly membership fee will be billed automatically each month for as long as I wish to remain a member.  I am providing the information on this form directly to The Auto CostCoverage Plan to activate my membership. This authorization shall remain in effect until I cancel by calling (888) 743-4419 or contacting AutoCostCoverage on their website via "Contact Us".  By submitting this application, I accept the <a href="#">Terms of Membership</a> and Terms of Offer above.</p>
                                        <div class="payment-accept">
                                        	<div class="payment-chkbox">
                                            	 <?php echo drupal_render($form['solutions']['terms_and_condition']); ?>
                                            </div>
                                            <div class="agree-txt">
                                            	<p>I have read and agree to the <a href="#">Terms of Membership.</a></p>
                                            </div>
                                        </div>
                                        <div class="confirm-btn">
                                        	<a href="#"><img src="<?php echo base_path() . drupal_get_path('module', 'multistep') ; ?>/images/confirm-btn.png" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php echo drupal_render_children($form); ?>